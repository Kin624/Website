export default function Footer() {
  return (
    <footer className="mt-20 border-t border-neon-cyan/10 py-8">
      <div className="mx-auto max-w-5xl px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <div className="h-6 w-6 rounded-md link-gradient flex items-center justify-center">
            <svg className="h-3.5 w-3.5 text-black" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="16" />
              <line x1="8" y1="12" x2="16" y2="12" />
            </svg>
          </div>
          <span className="text-sm font-semibold text-gradient">Kinzi Dev</span>
        </div>
        <p className="text-xs text-gray-600">
          &copy; {new Date().getFullYear()} Kinzi Dev. All rights reserved.
        </p>
        <p className="text-xs text-gray-700 mt-1">Created By Kinzi Dev</p>
      </div>
    </footer>
  );
}
