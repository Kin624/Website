interface SocialLink {
  href: string;
  icon: string;
  label: string;
}

const socialLinks: SocialLink[] = [
  {
    href: "https://t.me/kinzicpmchannel",
    icon: "https://cdn-icons-png.flaticon.com/512/174/174855.png",
    label: "Telegram",
  },
  {
    href: "https://youtube.com/@szdeath01?si=A3PVzpK9KiTyZbsi",
    icon: "https://site-unifecaf.vercel.app/_next/static/media/youtube.3f452be5.png",
    label: "YouTube",
  },
];

export default function SocialIcons() {
  return (
    <div className="flex justify-center gap-4 my-5">
      {socialLinks.map((link, index) => (
        <a
          key={index}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          title={link.label}
          className="group relative"
        >
          <div className="w-11 h-11 rounded-xl glass flex items-center justify-center transition-all duration-300 group-hover:border-neon-cyan/40 group-hover:shadow-lg group-hover:shadow-neon-cyan/20 group-hover:scale-110">
            <img
              src={link.icon}
              alt={link.label}
              className="w-6 h-6 filter brightness-0 invert transition-transform duration-200"
            />
          </div>
          <span className="absolute -bottom-7 left-1/2 -translate-x-1/2 text-[10px] text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            {link.label}
          </span>
        </a>
      ))}
    </div>
  );
}
