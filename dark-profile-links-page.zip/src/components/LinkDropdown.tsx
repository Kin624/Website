import { useState, useRef, useEffect } from "react";

interface DropdownItem {
  label: string;
  href: string;
}

interface LinkDropdownProps {
  icon: string;
  title: string;
  items: DropdownItem[];
  delay?: number;
}

export default function LinkDropdown({ icon, title, items, delay = 0 }: LinkDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    window.addEventListener("click", handleClickOutside);
    return () => window.removeEventListener("click", handleClickOutside);
  }, []);

  return (
    <div
      ref={ref}
      className="relative animate-slide-up"
      style={{ animationDelay: `${delay}ms`, opacity: 0 }}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 w-full link-gradient text-black px-5 py-4 rounded-xl font-bold text-base shadow-lg shadow-neon-cyan/30 hover:shadow-neon-cyan/50 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
      >
        <img
          src={icon}
          alt={title}
          className="w-8 h-8 rounded-md object-cover border border-black/10"
        />
        <span className="flex-1 text-left">{title}</span>
        <svg
          className={`w-4 h-4 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
          fill="none"
          stroke="currentColor"
          strokeWidth={2.5}
          viewBox="0 0 24 24"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 glass rounded-xl p-2 animate-fade-in z-50">
          {items.map((item, index) => (
            <a
              key={index}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 px-4 py-3 rounded-lg text-white font-semibold text-sm hover:bg-neon-cyan/10 transition-colors group/item"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan opacity-50 group-hover/item:opacity-100 transition-opacity" />
              {item.label}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
