import SocialIcons from "../components/SocialIcons";
import LinkDropdown from "../components/LinkDropdown";

const gameLinks = [
  {
    icon: "https://cdn.nichesites.pikoya.com/apps4blast_com/images/games/54615/hive_600x600.jpg",
    title: "Car Parking Multiplayer",
    items: [
      { label: "Accounts", href: "https://t.me/kinzicpmchannel" },
      { label: "Script", href: "#" },
    ],
  },
  {
    icon: "https://play-lh.googleusercontent.com/1DhZDejbhLxExB4o4WyhtcIrpO5s4BaWqbk3nsjl64TM9nwO3iCQqpV18ZO3PyklnA",
    title: "Car Parking Multiplayer 2",
    items: [
      {
        label: "Script",
        href: "https://pay.risepay.com.br/Pay/d37ae5b3a08946daa4204aac2333bb73",
      },
    ],
  },
  {
    icon: "https://m.media-amazon.com/images/I/612HrNi7o8L.png",
    title: "Real Racing 3",
    items: [{ label: "Accounts", href: "#" }],
  },
];

export default function Home() {
  return (
    <div className="pt-24 pb-10 px-4">
      <div className="mx-auto max-w-md text-center animate-fade-in">
        {/* Profile */}
        <div className="relative inline-block mb-6">
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-neon-cyan to-neon-blue blur-xl opacity-30 animate-glow-pulse" />
          <img
            src="https://github.com/Kin624/KinzPanel/blob/main/photo_2025-06-18_19-31-34.jpg?raw=true"
            alt="Photo Profile"
            className="relative w-36 h-36 rounded-full border-4 border-white/90 object-cover shadow-2xl animate-float"
          />
        </div>

        {/* Name */}
        <h1 className="text-3xl font-bold mb-1 tracking-tight">
          <span className="text-gradient">Kinzi</span> Dev
        </h1>
        <p className="text-gray-500 text-sm mb-4">Game Scripts & Accounts</p>

        {/* Social Icons */}
        <SocialIcons />

        {/* Divider */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent to-neon-cyan/30" />
          <span className="text-xs text-gray-500 font-medium tracking-widest uppercase">Games</span>
          <div className="flex-1 h-px bg-gradient-to-l from-transparent to-neon-cyan/30" />
        </div>

        {/* Game Links */}
        <div className="flex flex-col gap-4">
          {gameLinks.map((game, index) => (
            <LinkDropdown
              key={index}
              icon={game.icon}
              title={game.title}
              items={game.items}
              delay={index * 100}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
