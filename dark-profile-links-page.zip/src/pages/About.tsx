export default function About() {
  const stats = [
    { label: "Projects", value: "15+" },
    { label: "Clients", value: "200+" },
    { label: "Scripts", value: "50+" },
    { label: "Years", value: "3+" },
  ];

  const skills = [
    { name: "Game Scripting", level: 95 },
    { name: "Web Development", level: 88 },
    { name: "Reverse Engineering", level: 82 },
    { name: "UI/UX Design", level: 75 },
  ];

  return (
    <div className="pt-24 pb-10 px-4">
      <div className="mx-auto max-w-2xl">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-3xl font-bold mb-3">
            About <span className="text-gradient">Me</span>
          </h1>
          <p className="text-gray-500 text-sm max-w-md mx-auto">
            Passionate developer and gaming enthusiast creating scripts, tools, and accounts for the community.
          </p>
        </div>

        {/* Profile Card */}
        <div className="glass rounded-2xl p-6 mb-8 animate-slide-up" style={{ opacity: 0 }}>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <img
              src="https://github.com/Kin624/KinzPanel/blob/main/photo_2025-06-18_19-31-34.jpg?raw=true"
              alt="Kinzi Dev"
              className="w-24 h-24 rounded-2xl object-cover border-2 border-neon-cyan/30"
            />
            <div className="text-center sm:text-left">
              <h2 className="text-xl font-bold mb-1">Kinzi Dev</h2>
              <p className="text-neon-cyan text-sm font-medium mb-2">Game Script Developer</p>
              <p className="text-gray-400 text-sm leading-relaxed">
                I'm a developer specialized in game scripts and modding. I create high-quality scripts
                and accounts for popular mobile games, helping players enhance their gaming experience.
              </p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="glass rounded-xl p-4 text-center animate-slide-up hover:border-neon-cyan/30 transition-colors"
              style={{ animationDelay: `${(index + 1) * 100}ms`, opacity: 0 }}
            >
              <div className="text-2xl font-bold text-gradient mb-1">{stat.value}</div>
              <div className="text-xs text-gray-500 font-medium uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Skills */}
        <div className="glass rounded-2xl p-6 animate-slide-up" style={{ animationDelay: "500ms", opacity: 0 }}>
          <h3 className="text-lg font-bold mb-5">
            <span className="text-gradient">Skills</span>
          </h3>
          <div className="space-y-4">
            {skills.map((skill, index) => (
              <div key={index}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="text-gray-300 font-medium">{skill.name}</span>
                  <span className="text-neon-cyan font-bold">{skill.level}%</span>
                </div>
                <div className="h-2 rounded-full bg-dark-border overflow-hidden">
                  <div
                    className="h-full rounded-full link-gradient transition-all duration-1000 ease-out"
                    style={{ width: `${skill.level}%`, animationDelay: `${(index + 1) * 200}ms` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="mt-8 animate-slide-up" style={{ animationDelay: "600ms", opacity: 0 }}>
          <h3 className="text-lg font-bold mb-5 text-center">
            <span className="text-gradient">Journey</span>
          </h3>
          <div className="space-y-4">
            {[
              { year: "2022", text: "Started learning game scripting and modding" },
              { year: "2023", text: "Launched first game script for Car Parking Multiplayer" },
              { year: "2024", text: "Expanded to CPM2 and Real Racing 3 scripts" },
              { year: "2025", text: "Growing community with 200+ active clients" },
            ].map((item, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 rounded-full bg-neon-cyan shadow-lg shadow-neon-cyan/40" />
                  {index < 3 && <div className="w-0.5 h-full bg-neon-cyan/20" />}
                </div>
                <div className="pb-4">
                  <span className="text-neon-cyan text-xs font-bold tracking-wider">{item.year}</span>
                  <p className="text-gray-400 text-sm mt-1">{item.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
