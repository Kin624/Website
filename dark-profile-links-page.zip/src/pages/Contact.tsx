import { useState } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  const contactMethods = [
    {
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
        </svg>
      ),
      label: "Telegram",
      value: "@kinzicpmchannel",
      href: "https://t.me/kinzicpmchannel",
    },
    {
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
          <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19.1c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z" />
          <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" />
        </svg>
      ),
      label: "YouTube",
      value: "@szdeath01",
      href: "https://youtube.com/@szdeath01?si=A3PVzpK9KiTyZbsi",
    },
  ];

  return (
    <div className="pt-24 pb-10 px-4">
      <div className="mx-auto max-w-2xl">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-3xl font-bold mb-3">
            Get In <span className="text-gradient">Touch</span>
          </h1>
          <p className="text-gray-500 text-sm max-w-md mx-auto">
            Have a question or want to work together? Reach out and I'll get back to you as soon as possible.
          </p>
        </div>

        {/* Contact Methods */}
        <div className="grid sm:grid-cols-2 gap-4 mb-10">
          {contactMethods.map((method, index) => (
            <a
              key={index}
              href={method.href}
              target="_blank"
              rel="noopener noreferrer"
              className="glass rounded-xl p-5 flex items-center gap-4 animate-slide-up hover:border-neon-cyan/30 hover:shadow-lg hover:shadow-neon-cyan/10 transition-all duration-300 group"
              style={{ animationDelay: `${index * 100}ms`, opacity: 0 }}
            >
              <div className="w-12 h-12 rounded-xl link-gradient flex items-center justify-center text-black group-hover:scale-110 transition-transform">
                {method.icon}
              </div>
              <div>
                <div className="text-gray-500 text-xs font-medium uppercase tracking-wider">{method.label}</div>
                <div className="text-white font-semibold text-sm">{method.value}</div>
              </div>
            </a>
          ))}
        </div>

        {/* Contact Form */}
        <div className="glass rounded-2xl p-6 animate-slide-up" style={{ animationDelay: "200ms", opacity: 0 }}>
          <h2 className="text-lg font-bold mb-5">
            <span className="text-gradient">Send a Message</span>
          </h2>

          {submitted && (
            <div className="mb-4 p-3 rounded-lg bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan text-sm text-center animate-fade-in">
              ✓ Message sent successfully! I'll get back to you soon.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-500 font-medium mb-1.5 uppercase tracking-wider">
                  Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Your name"
                  className="w-full px-4 py-3 rounded-xl bg-dark-card border border-dark-border text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-neon-cyan/50 focus:shadow-lg focus:shadow-neon-cyan/10 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 font-medium mb-1.5 uppercase tracking-wider">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 rounded-xl bg-dark-card border border-dark-border text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-neon-cyan/50 focus:shadow-lg focus:shadow-neon-cyan/10 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-gray-500 font-medium mb-1.5 uppercase tracking-wider">
                Subject
              </label>
              <select
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                required
                className="w-full px-4 py-3 rounded-xl bg-dark-card border border-dark-border text-white text-sm focus:outline-none focus:border-neon-cyan/50 transition-all appearance-none"
              >
                <option value="" disabled>Select a subject</option>
                <option value="scripts">Game Scripts</option>
                <option value="accounts">Game Accounts</option>
                <option value="custom">Custom Request</option>
                <option value="support">Support</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-500 font-medium mb-1.5 uppercase tracking-wider">
                Message
              </label>
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                required
                rows={4}
                placeholder="Type your message..."
                className="w-full px-4 py-3 rounded-xl bg-dark-card border border-dark-border text-white text-sm placeholder:text-gray-600 focus:outline-none focus:border-neon-cyan/50 focus:shadow-lg focus:shadow-neon-cyan/10 transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl link-gradient text-black font-bold text-sm hover:shadow-lg hover:shadow-neon-cyan/30 active:scale-[0.98] transition-all duration-200"
            >
              Send Message
            </button>
          </form>
        </div>

        {/* FAQ */}
        <div className="mt-10 animate-slide-up" style={{ animationDelay: "400ms", opacity: 0 }}>
          <h2 className="text-lg font-bold mb-5 text-center">
            <span className="text-gradient">FAQ</span>
          </h2>
          <div className="space-y-3">
            {[
              {
                q: "How fast is delivery?",
                a: "Scripts and accounts are delivered within 24 hours of payment confirmation.",
              },
              {
                q: "Are the scripts safe?",
                a: "Yes, all scripts include anti-ban protection and are tested thoroughly before release.",
              },
              {
                q: "Do you offer refunds?",
                a: "Refunds are available within 24 hours if the product doesn't work as described.",
              },
              {
                q: "Can I request custom scripts?",
                a: "Absolutely! Contact me via Telegram with your requirements and I'll provide a quote.",
              },
            ].map((faq, index) => (
              <div key={index} className="glass rounded-xl p-4 hover:border-neon-cyan/20 transition-colors">
                <h4 className="text-white font-semibold text-sm mb-1">{faq.q}</h4>
                <p className="text-gray-500 text-xs leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
