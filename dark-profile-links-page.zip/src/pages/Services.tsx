export default function Services() {
  const services = [
    {
      icon: "🎮",
      title: "Game Scripts",
      description: "Custom scripts for Car Parking Multiplayer, CPM2, and Real Racing 3. Unlock features, modify gameplay, and enhance your experience.",
      features: ["Anti-ban protection", "Regular updates", "Easy installation"],
    },
    {
      icon: "👤",
      title: "Game Accounts",
      description: "Premium game accounts with rare items, maxed stats, and exclusive content. Ready-to-use accounts for popular mobile games.",
      features: ["Verified accounts", "Instant delivery", "Full access"],
    },
    {
      icon: "🔧",
      title: "Custom Mods",
      description: "Tailored modifications for your favorite games. Request specific features and get personalized solutions.",
      features: ["Custom requests", "Fast turnaround", "Support included"],
    },
    {
      icon: "🌐",
      title: "Web Development",
      description: "Modern, responsive websites and web applications. From landing pages to complex web platforms.",
      features: ["Responsive design", "SEO optimized", "Fast performance"],
    },
    {
      icon: "📱",
      title: "App Development",
      description: "Mobile application development for Android and iOS platforms with modern UI/UX design.",
      features: ["Cross-platform", "Native performance", "App store ready"],
    },
    {
      icon: "🛡️",
      title: "Security Tools",
      description: "Security analysis and protection tools for gaming platforms and applications.",
      features: ["Vulnerability scanning", "Protection scripts", "Security audits"],
    },
  ];

  const pricing = [
    {
      name: "Basic",
      price: "R$30",
      period: "/script",
      features: ["1 Game Script", "7 Days Support", "Basic Updates"],
      popular: false,
    },
    {
      name: "Pro",
      price: "R$60",
      period: "/script",
      features: ["2 Game Scripts", "30 Days Support", "Priority Updates", "Custom Features"],
      popular: true,
    },
    {
      name: "Premium",
      price: "R$100",
      period: "/month",
      features: ["All Scripts", "Unlimited Support", "Instant Updates", "Custom Requests", "VIP Access"],
      popular: false,
    },
  ];

  return (
    <div className="pt-24 pb-10 px-4">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-3xl font-bold mb-3">
            My <span className="text-gradient">Services</span>
          </h1>
          <p className="text-gray-500 text-sm max-w-md mx-auto">
            Professional game scripts, accounts, and development services to level up your experience.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className="glass rounded-2xl p-5 animate-slide-up hover:border-neon-cyan/30 hover:shadow-lg hover:shadow-neon-cyan/10 transition-all duration-300 group"
              style={{ animationDelay: `${index * 80}ms`, opacity: 0 }}
            >
              <div className="text-3xl mb-3 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-white font-bold text-base mb-2">{service.title}</h3>
              <p className="text-gray-500 text-xs leading-relaxed mb-3">{service.description}</p>
              <ul className="space-y-1.5">
                {service.features.map((feature, fi) => (
                  <li key={fi} className="flex items-center gap-2 text-xs text-gray-400">
                    <span className="w-1 h-1 rounded-full bg-neon-cyan" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="text-center mb-8 animate-fade-in">
          <h2 className="text-2xl font-bold mb-2">
            <span className="text-gradient">Pricing</span>
          </h2>
          <p className="text-gray-500 text-sm">Simple and transparent pricing</p>
        </div>

        <div className="grid sm:grid-cols-3 gap-4">
          {pricing.map((plan, index) => (
            <div
              key={index}
              className={`glass rounded-2xl p-5 text-center animate-slide-up transition-all duration-300 hover:scale-[1.02] ${
                plan.popular ? "border-neon-cyan/40 shadow-lg shadow-neon-cyan/20" : ""
              }`}
              style={{ animationDelay: `${(index + 6) * 80}ms`, opacity: 0 }}
            >
              {plan.popular && (
                <div className="inline-block px-3 py-0.5 rounded-full text-[10px] font-bold text-black link-gradient mb-3">
                  POPULAR
                </div>
              )}
              <h3 className="text-white font-bold text-lg mb-1">{plan.name}</h3>
              <div className="mb-4">
                <span className="text-3xl font-bold text-gradient">{plan.price}</span>
                <span className="text-gray-500 text-xs">{plan.period}</span>
              </div>
              <ul className="space-y-2 mb-5">
                {plan.features.map((feature, fi) => (
                  <li key={fi} className="text-sm text-gray-400">{feature}</li>
                ))}
              </ul>
              <a
                href="https://t.me/kinzicpmchannel"
                target="_blank"
                rel="noopener noreferrer"
                className={`inline-block w-full py-2.5 rounded-lg font-bold text-sm transition-all duration-200 ${
                  plan.popular
                    ? "link-gradient text-black hover:shadow-lg hover:shadow-neon-cyan/30"
                    : "border border-neon-cyan/30 text-neon-cyan hover:bg-neon-cyan/10"
                }`}
              >
                Get Started
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
